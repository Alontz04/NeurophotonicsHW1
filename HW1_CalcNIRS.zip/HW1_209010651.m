% Neurophotonics HW1
clear all
close all
clc



dataFile=["FN_032_V1_Postdose1_Nback" "FN_031_V2_Postdose2_Nback"];
SDS=3;
tissueType="adult_head";
extinctionCoefficientsFile=[];
DPFperTissueFile=[];
relDPFfile=[];
plotChannelIdx=1:2; % plotChannelIdx - vector with numbers in the range of [1-20] indicating channels to plot. If empty - none is plotted. (default = [])
% plotChannelIdx=1:20; % plotChannelIdx - vector with numbers in the range of [1-20] indicating channels to plot. If empty - none is plotted. (default = [])


% Initialize structures
dHbR = struct();
dHbO = struct();

for fileIndex=1:length(dataFile)
    % Call CalcNIRS function

    [ dHbRData , dHbOData, figdata ] = CalcNIRS(dataFile(fileIndex), SDS, tissueType, plotChannelIdx, extinctionCoefficientsFile, DPFperTissueFile, relDPFfile);
    % Store data in the structures
    fig.([dataFile(fileIndex)])=figdata;
    dHbR.([dataFile(fileIndex)]) = dHbRData;
    dHbO.([string(dataFile(fileIndex))]) = dHbOData;
end





