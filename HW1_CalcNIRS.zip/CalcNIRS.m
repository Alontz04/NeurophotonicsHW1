function [ dHbR , dHbO, fig ] = CalcNIRS(dataFile, SDS, tissueType, plotChannelIdx, extinctionCoefficientsFile, DPFperTissueFile, relDPFfile)
%% CalcNIRS - calculate and plot HbR HbO
% Input:
% dataFile - .mat file with intensity data.
% DS.Lambda : two wavelengths (in nm)
% t : time vector
% d : intensity data of 20 channels
% 20 first rows-> first wavelength, 20 last rows->second wavelength
% SDS - Source-Detector Separation distance in cm
% tissueType - one of the rows in DPFperTissueFile (for example 'adult_forearm' \ 'baby_head' \ 'adult_head' \
% 'adult_leg' )
% plotChannelIdx - vector with numbers in the range of [1-20] indicating channels to plot. If empty - none is
% plotted. (default = [])
%
% extinctionCoefficientsFile - .csv file with the following columns : wavelength, Water, HbO2, HHb,
% FatSoybean
% default = '.\ExtinctionCoefficientsData.csv' (if not passed or empty)
% DPFperTissueFile - .txt file with two columns: Tissue and DPF (Tissue is tissue type, corresponding with
% tissueType input variable)
% measured at 807nm
% default = '.\DPFperTissue.txt' (if not passed or empty)
% relDPFfile - relative DPF according to wavelength
% default = '.\RelativeDPFCoefficients.csv' (if not passed or empty)
%
% Output :
% dHbR - HbR concentration change for all channels (nx20) where n is time vector length
% dHbO - HbO concentration change for all channels (nx20) where n is time vector length
% fig - handle to figure. Empty if plotChannelIdx==[].

% Load and arrange the provided data
if nargin < 5 || isempty(extinctionCoefficientsFile)
    extinctionCoefficientsFile = '.\ExtinctionCoefficientsData.csv';
end
if nargin < 6 || isempty(DPFperTissueFile)
    DPFperTissueFile = '.\DPFperTissue.txt';
end
if nargin < 7 || isempty(relDPFfile)
    relDPFfile = '.\RelativeDPFCoefficients.csv';
end
if nargin < 4
    plotChannelIdx = [];
end

% Load DPF per tissue
DPFperTissue = readtable(DPFperTissueFile);
rows = strcmp(DPFperTissue.Tissue, tissueType); % Find rows matching the tissueType
filteredTable = DPFperTissue(rows, :); % Filter the table based on the tissueType
adultHeadDPF = filteredTable{1, 2}; % Extract the DPF value for the given tissue type

% Load extinction coefficients for all wavelength
MuE = readtable(extinctionCoefficientsFile);
tableIndex = 1;
wavelength = table2array(MuE(1 == ~isnan(MuE{:, tableIndex}), tableIndex)); tableIndex = tableIndex + 1;
waterMuE = table2array(MuE(1 == ~isnan(MuE{:, tableIndex}), tableIndex)); tableIndex = tableIndex + 1;
HbOMuE = table2array(MuE(1 == ~isnan(MuE{:, tableIndex}), tableIndex)); tableIndex = tableIndex + 1; % This is HbO - Only different name
HbRMuE = table2array(MuE(1 == ~isnan(MuE{:, tableIndex}), tableIndex)); tableIndex = tableIndex + 1; % This is HbR - Only different name
fatsoybeanMuE = table2array(MuE(1 == ~isnan(MuE{:, tableIndex}), tableIndex)); tableIndex = tableIndex + 1;

% Load relative DPF coefficients
realtiveDPF = readtable(relDPFfile);

% Load data file - the intensity , time vector; it's the measurement data
data = load(dataFile);
d = data.d; % The intensity
t = data.t; % Time
SD = data.SD; % Wavelength

% Finding the pathlength the photon has traveled
[~, lambdaIndex] = min(abs(SD.Lambda - realtiveDPF{:, 1})); % find the correct index of the wavelength according to the provided data
rDPF = realtiveDPF{lambdaIndex, 2}; % The relative DPF factor value from the table
adultHeadDPFCorrected = adultHeadDPF .* rDPF; % The final DPF to be used after correction
pathlength = SDS * adultHeadDPFCorrected; % The pathlength the photon has traveled

% Get the correct constants according to the wavelength
[~, lambdaIndex] = min(abs(SD.Lambda - wavelength)); % again find the correct index of wavelength
waterMu_Use = waterMuE(lambdaIndex);
HbOMu_Use = HbOMuE(lambdaIndex); % The array to use for computation as we don't need all of the array
HbRMu_Use = HbRMuE(lambdaIndex);
fatsoybeanMu_Use = fatsoybeanMuE(lambdaIndex);

% Calculate the dHbO and dHbR
firlambdaIndex = 1:20; % Indexes of the first wavelength measurement
seclambdaIndex = 21:40; % Indexes of the second wavelength measurement
channelLength = size(d, 2) / 2; % How many channels there are
wavelengthsLength = length(SD.Lambda); % How many wavelengths did we measure with

% Initialize the array so we split it conveniently
OD = zeros(length(t), channelLength, wavelengthsLength);
OD(:, :, 1) = log10(d(1, firlambdaIndex) ./ d(:, firlambdaIndex)); % Store the first wavelength results
OD(:, :, 2) = log10(d(1, seclambdaIndex) ./ d(:, seclambdaIndex)); % Store the second wavelength results

% Initialize the arrays for HbO and HbR
dHbO = zeros(length(t), channelLength);
dHbR = zeros(length(t), channelLength);

for channelIndex = 1:channelLength % The wavelength in hand
    for timeIndex = 1:length(t)
        result = (1 ./ pathlength) .* (inv([HbOMu_Use HbRMu_Use]) * squeeze(OD(timeIndex, channelIndex, :)));
        dHbO(timeIndex, channelIndex) = result(1);
        dHbR(timeIndex, channelIndex) = result(2);
    end
end

% Plotting the channels if plotChannelIdx is set
fig = {};
if ~isempty(plotChannelIdx)
    cmap = ['b'; 'r'];
    fig = figure('Color', 'White', 'DefaultAxesFontUnits', 'Points', 'DefaultAxesFontSize', 18, ...
        'DefaultAxesFontName', 'Times New Roman', 'DefaultTextFontUnits', 'Points', ...
        'DefaultTextFontSize', 20, 'DefaultTextFontName', 'Times New Roman', ...
        'DefaultLineLineWidth', 1);
    % Determine subplot grid size
    numPlots = length(plotChannelIdx)+2;
    numRows = ceil(sqrt(numPlots));
    numCols = ceil(numPlots / numRows);

    for subplotIndex = 1:length(plotChannelIdx)
        channelIndex = plotChannelIdx(subplotIndex);
        subplot(numRows, numCols, channelIndex);
        scatter(t, dHbR(:, channelIndex), 'MarkerEdgeColor', cmap(1,:), 'MarkerFaceColor', cmap(1,:), ...
            'Marker', 'o', 'LineWidth', 0.5, 'DisplayName', 'HbR');
        hold on;
        scatter(t, dHbO(:, channelIndex), 'MarkerEdgeColor', cmap(2,:), 'MarkerFaceColor', cmap(2,:), ...
            'Marker', 'square', 'LineWidth', 0.5, 'DisplayName', 'HbO');
        hold off;
        xlabel("Time [s]");
        ylabel("\Delta");
        title(['Channel ', num2str(channelIndex)]);
        legend('show');
    end

    % Fourier Transform and SNR calculation
    signal = d(:, 1); % First channel
    signal2 = d(:, 21); % Second channel

    Fs = 1 / mean(diff(t)); % Sampling frequency = pulseFrequency
    L = length(signal);
    Y = fft(signal) / L;
    Y2 = fft(signal2) / L;

    f = Fs / L * (0:L-1);

    % Remove DC component
    Y(1) = 0;
    Y2(1) = 0;

    fftChannel1 = abs(Y); % Magnitude of the Fourier Transform
    fftChannel1_2 = abs(Y2); % Magnitude of the Fourier Transform

    % Calculate SNR
    noiseThresholdFreq = 2.5; % Define noise level
    noise = mean(fftChannel1(f >= noiseThresholdFreq & f <= Fs/2)); % Find the noise in the signal

    [~, pulseScanIndexStart] = min(abs(f - 1)); % Scan from 1 Hz
    [~, pulseScanIndexEnd] = min(abs(f - noiseThresholdFreq)); % Scan up to 2.5 Hz = noise
    scanPulse = fftChannel1(pulseScanIndexStart:pulseScanIndexEnd);

    noise2 = mean(fftChannel1_2(f >= noiseThresholdFreq & f <= Fs/2)); % Find the noise in the signal
    scanPulse2 = fftChannel1_2(pulseScanIndexStart:pulseScanIndexEnd);

    [signalStrength, PulseFrequency] = max(scanPulse); % Adjust the threshold as needed
    [signalStrength2, PulseFrequency2] = max(scanPulse2); % Adjust the threshold as needed

    correctionFactor=2; % Compansating for half the signal, the energy is displaced between 2 areas

    SNR(1) = correctionFactor*signalStrength / noise; % Signal-to-Noise Ratio
    SNR(2) = correctionFactor*signalStrength2 / noise2; % Signal-to-Noise Ratio

    disp(['SNR: ', num2str(mean(SNR)),' std:',num2str(std(SNR))]);

    % Plot the Fourier Transform
    subplot(numRows, numCols, (numCols*numRows-1):numCols*numRows);
    hold all
cmap=orderedcolors("gem");

    semilogy(f, fftChannel1, "LineWidth", 1.5,'HandleVisibility','off');  % Plot the Fourier transform of channel 1
    semilogy(f, fftChannel1_2, "LineWidth", 1.5,'HandleVisibility','off');  % Plot the Fourier transform of channel 2
    semilogy(f(pulseScanIndexStart + PulseFrequency), signalStrength, 'bo', 'DisplayName', ['Hear Beat Peak ',num2str(SD.Lambda(1))]);
    semilogy(f(pulseScanIndexStart + PulseFrequency2), signalStrength2, 'ro', 'DisplayName', ['Hear Beat Peak',num2str(SD.Lambda(2))]);
    % Add SNR text to the plot
    xPos = 1.5; % Position for text (70% of the max frequency)
    yPos = 0.7 * (max(fftChannel1)); % Position for text (70% of the max amplitude)
    text(xPos, yPos, ['SNR: ', num2str(mean(SNR), '%.2f'),' std:',num2str(std(SNR), '%.2f')], 'FontSize', 18, 'Color', 'red', 'FontWeight', 'bold');
    hold off


    title("Magnitude of the Fourier transform");
    xlabel('Frequency (Hz)');
    ylabel('|fft(channel 1)|');
    legend('boxoff');
    xlim([0 Fs/2]);
    yscale log


end

end
